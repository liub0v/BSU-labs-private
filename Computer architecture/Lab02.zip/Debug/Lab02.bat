@echo off
set /P "proc=Enter number of processes: "
"C:\Program Files\Microsoft MPI\Bin\mpiexec.exe" -n %proc% Lab02.exe
pause
