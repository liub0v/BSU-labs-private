#include <mpi.h>
#include <stdio.h>
#include <fstream>
#include <sys\timeb.h>

void print_results(int* c, int n, int k)
{
    int i, j;

    printf ("\n\nC = \n");
    for (i = 0; i < n; i++) {
            for (j = 0; j < k; j++) {
                    printf(" %d", c[i*k + j]);
            }
            printf ("\n");
    }
    printf ("\n\n");
}

int main(int argc, char** argv) 
{
	int size, rank;
	int n, m, k;
	int *a = NULL, *b = NULL, *c = NULL, *aa = NULL, *cc = NULL;

    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	if (rank == 0) {
		std::ifstream fin("input.txt");
		fin >> n >> m >> k;

		a = new int[n*m];
		for (int i = 0; i < n*m; i++) {
			fin >> a[i];
		}

		b = new int[m*k];
		for (int i = 0; i < m*k; i++) {
			fin >> b[i];
		}

		c = new int[n*k];
	}

	MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&k, 1, MPI_INT, 0, MPI_COMM_WORLD);


	if (size != n && size != 1) {
        if(rank == 0)
            printf("Error: %d processes required instead of %d\n", n, size);
        MPI_Barrier(MPI_COMM_WORLD);
        MPI_Abort(MPI_COMM_WORLD, MPI_ERR_OTHER);
        return -1;
    }

	aa = new int[n*m/size];
	cc = new int[n*k/size];

	if (rank != 0){ // root have already allocated mem
		b = new int[m*k];
	}
	MPI_Scatter(a, n*m/size, MPI_INT, aa, n*m/size, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(b, m*k, MPI_INT, 0, MPI_COMM_WORLD);

	double time = MPI_Wtime();
	int sum;
	for (int l = 0; l < n/size; l++)
		for (int i = 0; i < k; i++) {
			sum = 0;
			for (int j = l*m; j < (l+1)*m; j++) {
					sum += aa[j] * b[(j%m)*k + i];                
			}
			cc[l*k+i] = sum;
			//printf("[%d] cc[%d]=%d\n", rank, i, sum);
		}
	double time_end = MPI_Wtime();
	MPI_Gather(cc, n*k/size, MPI_INT, c, n*k/size, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);  
	
    MPI_Finalize();
    if (rank == 0){
        //print_results(c, n, k);
		printf("Calculation took: %.3lf sec.\n", time_end-time);
	}
}