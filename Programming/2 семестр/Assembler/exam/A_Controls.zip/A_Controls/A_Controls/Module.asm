.386
PUBLIC _Function1@12
.model flat

.code

	_Function1@12 proc
		push	ebp
		mov		ebp,	esp
		mov		ecx,	10
		mov		edi,	0
		
		cycle1:
			dec		ecx
			mov		esi,	10
			mov		ebx,	0
			
			mov		eax,	dword ptr[ebp + 8]	
			cycle2:
				cmp		eax,	0
				je		break2
				cdq
				div		esi
				cmp		edx,	ecx
				jne		not_equal_1
				mov		bl,		1
				not_equal_1:
			jmp		cycle2
			break2:

			mov		eax,	dword ptr[ebp + 12]	
			cycle3:
				cmp		eax,	0
				je		break3
				cdq
				div		esi
				cmp		edx,	ecx
				jne		not_equal_2
				mov		bh,		1
				not_equal_2:
			jmp		cycle3
			break3:
			
			and		bl,		bh
			cmp		bl,		1			
			jne		not_equal_3
			inc		edi
			mov		eax,	dword ptr[ebp + 16]
			mov		dword ptr[eax + 4 * edi],	ecx
			not_equal_3:
			inc ecx
		loop	cycle1
		mov		eax,	dword ptr[ebp + 16]
		mov		dword ptr[eax],	edi
		pop		ebp
		ret 12
	_Function1@12 endp

end