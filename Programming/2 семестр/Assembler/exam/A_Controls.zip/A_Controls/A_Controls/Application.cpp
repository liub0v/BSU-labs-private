#include "stdafx.h"
#include "WinApiModule.h"
#include <CommCtrl.h>
#include <string>

#define DLGTITLE  L"My dialog"
#define DLGFONT   L"MS Shell Dlg"

extern "C"	void __stdcall Function1(int, int, int*);

namespace Control
{
	int const IDC_Operand1TextBox        = 1002;
	int const IDC_Operand2TextBox		 = 1004;
	int const IDC_CalculateButton        = 1003;
	int const IDC_ResultLabel            = 1011;
}

// Эта структура — эмуляция пустого ресурса диалога.
// См. файл .rc в проекте WinAPI по умолчанию.
// По сути, что-то аналогичное заданию класса окна.
#pragma pack(push, 4)                 
static struct
{
	DWORD  style;
	DWORD  dwExtendedStyle;
	WORD   ccontrols; // Количество контролов. Контролы можно объявлять прямо тут, в этой структуре после всех полей, но зачем?
	short  x;
	short  y;
	short  cx;
	short  cy;
	WORD   menu;
	WORD   windowClass;
	WCHAR  wszTitle[ARRAYSIZE(DLGTITLE)];
	short  pointsize; // Масштабирование координат. См. FromUnit для преобразования координат.
	WCHAR  wszFont[ARRAYSIZE(DLGFONT)];
}
EmptyDialogTemplate =
{
   DS_SHELLFONT | DS_SETFONT | DS_MODALFRAME | DS_FIXEDSYS | WS_POPUP | WS_CAPTION | WS_SYSMENU, // Модальное!
   0x0,
   0,
   0, 0, 360, 180,
   0,                       // menu: none
   0,                       // window class: none
   DLGTITLE,                // Window caption
   8,                       // font pointsize
   DLGFONT,
};
#pragma pack(pop)

class Application
{
	static HWND _hDialog;
	static std::wstring operand1;
	static std::wstring operand2;
public:
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
	{
		switch (message)
		{
		case WM_LBUTTONDOWN:
		{
			OnClick(hWnd);
			return true;
		}
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			auto hdc = BeginPaint(hWnd, &ps);
			EndPaint(hWnd, &ps);
			break;
		}
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		return 0;
	}

private:
	static void OnClick(HWND hWnd)
	{
		// Восстанавливаем hInst по hWnd.
		auto hInst = (HINSTANCE)GetWindowLongPtr(hWnd, GWLP_HINSTANCE);
		// Запускаем диалог.
		DialogBoxIndirectParamW(hInst, (LPCDLGTEMPLATEW)&EmptyDialogTemplate, hWnd, DlgProc, NULL);
	}

	static INT_PTR CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
	{
		UNREFERENCED_PARAMETER(lParam);
		switch (message)
		{
		case WM_INITDIALOG:
		{
			_hDialog = hDlg;
			OnInitDialog();
			return (INT_PTR)TRUE;
		}

			case WM_COMMAND:
				return (INT_PTR)OnCommand(wParam);

			case WM_CLOSE:
				EndDialog(hDlg, IDCANCEL);
				break;
		}

		return (INT_PTR)FALSE;
	}

	static void OnInitDialog()
	{
		// Создаём все контролы.
		CreateDialogControl(L"EDIT", L"op1", ES_AUTOHSCROLL, 10, 10, 50, 12, Control::IDC_Operand1TextBox);
		CreateDialogControl(L"EDIT", L"op2", ES_AUTOHSCROLL, 10, 30, 50, 12, Control::IDC_Operand2TextBox);
		CreateDialogControl(L"STATIC", L"<result>", NULL, 70, 10, 50, 12, Control::IDC_ResultLabel);
		CreateDialogControl(L"BUTTON", L"calculate", NULL, 10, 50, 50, 12, Control::IDC_CalculateButton);
	}

	static HWND CreateDialogControl(const wchar_t* className, const wchar_t* text, DWORD style, int X, int Y, int width, int height, int id)
	{
		return CreateWindowEx(
			NULL,
			className,
			text,
			WS_VISIBLE | WS_CHILD | WS_TABSTOP | style,
			FromUnit(X), FromUnit(Y),
			FromUnit(width), FromUnit(height),
			_hDialog,
			(HMENU)id,
			nullptr, nullptr);
	}

	static int FromUnit(int value)
	{
		return MulDiv(value, LOWORD(GetDialogBaseUnits()), 4);
	}

	static BOOL OnCommand(WPARAM wParam)
	{
		auto controlID = LOWORD(wParam);
		auto notification = HIWORD(wParam);

		switch (controlID)
		{
			case Control::IDC_CalculateButton:			
			{
				SetResult();
				return TRUE;
			}

			case Control::IDC_Operand1TextBox:
			{
				auto ret_res = ProcessOperand1TextBox(notification);
				return ret_res;
			}

			case Control::IDC_Operand2TextBox:
			{
				auto ret_res = ProcessOperand2TextBox(notification);
				return ret_res;
			}
		}

		return FALSE;
	}

	static BOOL ProcessOperand1TextBox(WORD notification)
	{
		switch (notification)
		{
		case EN_CHANGE:
		{
			auto TextBox = GetControl(Control::IDC_Operand1TextBox);
			auto textLength = GetWindowTextLengthW(TextBox);
			operand1.resize(textLength + 1);
			SendMessage(TextBox, WM_GETTEXT, textLength + 1, (LPARAM)&operand1[0]);
			return TRUE;
		}

		default:
			return FALSE;
		}
	}

	static BOOL ProcessOperand2TextBox(WORD notification)
	{
		switch (notification)
		{
		case EN_CHANGE:
		{
			auto TextBox = GetControl(Control::IDC_Operand2TextBox);
			auto textLength = GetWindowTextLengthW(TextBox);
			operand2.resize(textLength + 1);
			SendMessage(TextBox, WM_GETTEXT, textLength + 1, (LPARAM)& operand2[0]);
			return TRUE;
		}

		default:
			return FALSE;
		}
	}

	static HWND GetControl(int id)
	{
		return GetDlgItem(_hDialog, id);
	}

	static BOOL SetResult()
	{
		bool error_occured = false;
		auto Label = GetControl(Control::IDC_ResultLabel);
		int* res = new int[20];
		int op1 = std::stoi(operand1);
		int op2 = std::stoi(operand2);
		Function1(op1, op2, res);
		std::wstring result = L"";
		for (int i = 0; i < res[0]; i++)
		{
			result.push_back('0' + res[i + 1]);
		}
		SendMessageW(Label, WM_SETTEXT, operand1.size() + 1, (LPARAM)&result[0]);
		delete[] res;
		return TRUE;
	}
};

std::wstring Application::operand1 = L"";
std::wstring Application::operand2 = L"";
HWND Application::_hDialog;

int APIENTRY WinMain(
	_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	auto winApiModule = WinApiModule(
		L"Dialog",
		L"Dialog",
		hInstance,
		Application::WndProc);

	return winApiModule.Run(nCmdShow);
}