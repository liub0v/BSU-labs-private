.386
PUBLIC _Function 
.model flat
.code 
_Function proc

_Function endp
end